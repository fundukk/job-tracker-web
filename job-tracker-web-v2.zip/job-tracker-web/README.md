# Job Application Tracker

A self-contained Flask web app: paste a job posting URL (LinkedIn, Handshake, Indeed, etc.),
it parses position/company/location/salary, you review and save. Jobs are stored in a
built-in SQLite database and shown right in the app. No Google account, no external APIs.

## Features
- Password login (single password via APP_PASSWORD env var)
- Automatic job parsing from LinkedIn / Handshake / generic job boards
- Review & edit before saving; salary normalization to annual
- Dashboard with all applications, status dropdown (Applied/Interview/Offer/Rejected/Saved)
- Duplicate URL detection, trash (soft delete), CSV export

## Run locally
```bash
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # then edit SECRET_KEY and APP_PASSWORD
python app.py          # open http://localhost:5000
```

## Deploy (Render)
- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app`
- Environment variables: `SECRET_KEY`, `APP_PASSWORD`
- Note: on Render's free tier the disk is ephemeral — the SQLite database resets on
  each deploy/restart. Use the Export CSV button to back up, or attach a persistent
  disk (paid) and set `DATA_DIR` to its mount path.
