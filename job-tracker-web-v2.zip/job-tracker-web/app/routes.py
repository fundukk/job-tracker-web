#!/usr/bin/env python3
"""
Main application routes.
Dashboard (job list), add-job flow, CSV export. No Google dependencies.
"""
import logging
from flask import (
    Blueprint, render_template, request, redirect, url_for,
    session, flash, Response,
)
from app.auth import require_login
from app.storage import (
    add_job as db_add_job,
    find_job_by_link,
    list_jobs,
    replace_last_job,
    delete_job,
    update_status,
    export_csv,
)
from app.parsers import process_job_url, validate_job_url, parse_handshake_text_wrapper
from core.salary import normalize_salary

logger = logging.getLogger(__name__)

main_bp = Blueprint("main", __name__)

STATUSES = ["Applied", "Interview", "Offer", "Rejected", "Saved"]


@main_bp.route("/")
@require_login
def index():
    """Dashboard: list of all tracked jobs."""
    jobs = list_jobs()
    return render_template("index.html", jobs=jobs, statuses=STATUSES)


@main_bp.route("/job", methods=["GET", "POST"])
@require_login
def job():
    """Add a job: paste URL (GET shows form, POST parses it)."""
    if request.method == "POST":
        job_url = request.form.get("job_url", "").strip()
        if not job_url:
            flash("Please provide a job URL", "error")
            return redirect(url_for("main.job"))

        is_valid, error_msg = validate_job_url(job_url)
        if not is_valid:
            flash(error_msg, "error")
            return redirect(url_for("main.job"))

        if "handshake" in job_url.lower():
            session["pending_handshake_url"] = job_url
            return render_template("handshake_text.html", job_url=job_url)

        try:
            job_data = process_job_url(job_url)
            return render_template("review_job.html", data=job_data)
        except Exception as e:
            logger.error("Error processing %s: %s", job_url, e, exc_info=True)
            flash(f"Error processing job: {e}", "error")
            return redirect(url_for("main.job"))

    return render_template("job.html")


@main_bp.route("/parse_handshake", methods=["POST"])
@require_login
def parse_handshake():
    """Parse a Handshake job from pasted text."""
    job_text = request.form.get("job_text", "").strip()
    job_url = session.get("pending_handshake_url", "")
    if not job_text:
        flash("Please paste the job description text", "error")
        return render_template("handshake_text.html", job_url=job_url)
    try:
        job_data = parse_handshake_text_wrapper(job_text, job_url)
        session.pop("pending_handshake_url", None)
        return render_template("review_job.html", data=job_data)
    except Exception as e:
        logger.error("Error parsing Handshake job: %s", e, exc_info=True)
        flash(f"Error parsing Handshake job: {e}", "error")
        return render_template("handshake_text.html", job_url=job_url)


@main_bp.route("/add_job", methods=["POST"])
@require_login
def add_job():
    """Save the reviewed/edited job to the database."""
    job_data = {
        k: request.form.get(k, "").strip()
        for k in (
            "position", "company", "location", "salary", "job_type",
            "remote", "link", "source", "notes",
        )
    }
    job_data["status"] = request.form.get("status", "Applied").strip()

    if job_data["salary"]:
        job_data["salary"] = normalize_salary(job_data["salary"])

    if request.form.get("replace_last_job") == "on":
        replaced = replace_last_job(job_data)
        flash(
            "Job replaced successfully! (Old entry moved to trash)" if replaced
            else "No previous job to replace. Added as new entry.",
            "success" if replaced else "warning",
        )
    else:
        if find_job_by_link(job_data.get("link", "")):
            flash("⚠️ This job URL is already in your tracker!", "error")
            return redirect(url_for("main.job"))
        db_add_job(job_data)
        flash("Job added successfully!", "success")

    return render_template("success.html", job_data=job_data)


@main_bp.route("/delete/<int:job_id>", methods=["POST"])
@require_login
def delete(job_id):
    delete_job(job_id)
    flash("Job moved to trash", "success")
    return redirect(url_for("main.index"))


@main_bp.route("/status/<int:job_id>", methods=["POST"])
@require_login
def status(job_id):
    new_status = request.form.get("status", "Applied")
    update_status(job_id, new_status)
    return redirect(url_for("main.index"))


@main_bp.route("/export.csv")
@require_login
def export():
    return Response(
        export_csv(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=job_applications.csv"},
    )
