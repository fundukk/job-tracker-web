#!/usr/bin/env python3
"""
SQLite storage for job applications.
Replaces the previous Google Sheets backend with a self-contained database.

The database file lives at DATA_DIR/jobs.db (DATA_DIR env var, default ./data).
"""
import os
import csv
import io
import sqlite3
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

COLUMNS = [
    "position", "company", "location", "salary", "job_type",
    "remote", "link", "source", "status", "notes",
]


def _db_path():
    data_dir = os.environ.get("DATA_DIR", os.path.join(os.getcwd(), "data"))
    os.makedirs(data_dir, exist_ok=True)
    return os.path.join(data_dir, "jobs.db")


def get_conn():
    conn = sqlite3.connect(_db_path())
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create the jobs table if it doesn't exist."""
    with get_conn() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                position TEXT, company TEXT, location TEXT, salary TEXT,
                job_type TEXT, remote TEXT, link TEXT, source TEXT,
                status TEXT, notes TEXT,
                date_added TEXT NOT NULL,
                deleted INTEGER NOT NULL DEFAULT 0
            )
            """
        )
    logger.info("Database initialized at %s", _db_path())


def add_job(job_data: dict) -> int:
    """Insert a job. Returns the new row id."""
    values = [job_data.get(c, "") for c in COLUMNS]
    with get_conn() as conn:
        cur = conn.execute(
            f"INSERT INTO jobs ({', '.join(COLUMNS)}, date_added) "
            f"VALUES ({', '.join('?' * len(COLUMNS))}, ?)",
            values + [datetime.now().strftime("%Y-%m-%d %H:%M")],
        )
        return cur.lastrowid


def find_job_by_link(link: str):
    """Return the job row with this link (not deleted), or None."""
    if not link:
        return None
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM jobs WHERE link = ? AND deleted = 0 LIMIT 1", (link,)
        ).fetchone()
        return row


def list_jobs(include_deleted: bool = False):
    """Return all jobs, newest first."""
    q = "SELECT * FROM jobs"
    if not include_deleted:
        q += " WHERE deleted = 0"
    q += " ORDER BY id DESC"
    with get_conn() as conn:
        return conn.execute(q).fetchall()


def replace_last_job(job_data: dict) -> bool:
    """Soft-delete the most recent job and insert the new one.
    Returns True if a previous job existed."""
    with get_conn() as conn:
        row = conn.execute(
            "SELECT id FROM jobs WHERE deleted = 0 ORDER BY id DESC LIMIT 1"
        ).fetchone()
        if row:
            conn.execute("UPDATE jobs SET deleted = 1 WHERE id = ?", (row["id"],))
    add_job(job_data)
    return bool(row)


def delete_job(job_id: int):
    """Soft-delete a job (moves it to trash)."""
    with get_conn() as conn:
        conn.execute("UPDATE jobs SET deleted = 1 WHERE id = ?", (job_id,))


def update_status(job_id: int, status: str):
    with get_conn() as conn:
        conn.execute("UPDATE jobs SET status = ? WHERE id = ?", (status, job_id))


def export_csv() -> str:
    """Return all non-deleted jobs as a CSV string (Excel-compatible)."""
    rows = list_jobs()
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["Date Added"] + [c.replace("_", " ").title() for c in COLUMNS])
    for r in rows:
        writer.writerow([r["date_added"]] + [r[c] or "" for c in COLUMNS])
    return buf.getvalue()
