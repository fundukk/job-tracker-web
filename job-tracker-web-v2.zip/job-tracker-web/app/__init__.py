#!/usr/bin/env python3
"""
Flask application factory for job-tracker-web.
Google-free version: password login + SQLite storage.
"""
import os
import logging
from datetime import timedelta
from flask import Flask
from dotenv import load_dotenv


def create_app():
    load_dotenv()

    missing = [v for v in ("SECRET_KEY", "APP_PASSWORD") if not os.environ.get(v)]
    if missing:
        msg = f"FATAL: Missing required environment variables: {', '.join(missing)}"
        print(f"\n{'=' * 80}\n{msg}\n{'=' * 80}\n")
        raise EnvironmentError(
            f"{msg}. Set them in your .env file (local) or environment (production)."
        )

    app = Flask(__name__, template_folder="../templates", static_folder="../static")
    app.secret_key = os.environ["SECRET_KEY"]
    app.permanent_session_lifetime = timedelta(days=90)

    configure_logging(app)

    from app.storage import init_db
    init_db()

    from app.auth import auth_bp
    from app.routes import main_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)

    app.logger.info("App initialized (password auth + SQLite storage)")
    return app


def configure_logging(app):
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)s [%(name)s] %(message)s"
    ))
    app.logger.setLevel(logging.INFO)
    root = logging.getLogger()
    if not root.handlers:
        root.addHandler(handler)
    root.setLevel(logging.INFO)


# PEP 562 lazy attribute: lets both `gunicorn app:app` (production)
# and `from app import app` (app.py) work without creating the app
# at import time (which would break tests that import app.parsers).
def __getattr__(name):
    if name == "app":
        return create_app()
    raise AttributeError(name)
