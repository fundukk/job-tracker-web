#!/usr/bin/env python3
"""
Simple password authentication (replaces Google OAuth).
One shared password is read from the APP_PASSWORD environment variable.
"""
import os
import hmac
import logging
from functools import wraps
from flask import Blueprint, render_template, request, redirect, url_for, session, flash

logger = logging.getLogger(__name__)

auth_bp = Blueprint("auth", __name__)


def require_login(f):
    """Decorator: redirect to login page if not authenticated."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("auth.login"))
        return f(*args, **kwargs)
    return wrapper


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        password = request.form.get("password", "")
        expected = os.environ.get("APP_PASSWORD", "")
        if expected and hmac.compare_digest(password, expected):
            session["logged_in"] = True
            session.permanent = True
            logger.info("Successful login")
            return redirect(url_for("main.index"))
        logger.warning("Failed login attempt")
        flash("Wrong password", "error")
    return render_template("login.html")


@auth_bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
